import React from "react";
    const JoinAuctionScreen = () => {

        return(
            <div className="container">
             JoinAuction Screen
             </div>
        )
    }


export default JoinAuctionScreen;
