import React from "react";
    const TodayAuctionScreen = () => {

        return(
            <div className="container">
             TodayAuction Screen
             </div>
        )
    }


export default TodayAuctionScreen;
