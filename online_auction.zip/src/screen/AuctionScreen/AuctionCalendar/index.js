import React from "react";
    const AuctionCalendarScreen = () => {

        return(
            <div className="container">
             AuctionCalendar Screen
             </div>
        )
    }


export default AuctionCalendarScreen;
