import React from "react";
    const ContactScreen = () => {

        return(
            <div className="container">
             Contact Screen
             </div>
        )
    }


export default ContactScreen;
