import React from "react";
    const FAQsScreen = () => {

        return(
            <div className="container">
             FAQs Screen
             </div>
        )
    }


export default FAQsScreen;
