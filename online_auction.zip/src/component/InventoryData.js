const InventoryData = [
    {
        id: 1,
        image: "images/car_A/1.jpg",
        location: "TX - DALLAS SOUTH",
        name: "2019 MERCEDES-BENZ A 220 4MATIC",
    },
    {
        id: 2,
        image: "images/car_B/1.jpg",
        location: "TX - DALLAS SOUTH",
        name: "2019 MERCEDES-BENZ A 220 4MATIC",
    },
    {
        id: 3,
        image: "images/car_C/1.jpg",
        location: "TX - DALLAS SOUTH",
        name: "2019 MERCEDES-BENZ A 220 4MATIC",
    },
    {
        id: 4,
        image: "images/car_D/1.jpg",
        location: "TX - DALLAS SOUTH",
        name: "2019 MERCEDES-BENZ A 220 4MATIC",
    },
    {
        id: 5,
        image: "images/car_E/1.jpg",
        location: "TX - DALLAS SOUTH",
        name: "2019 MERCEDES-BENZ A 220 4MATIC",
    },
    {
        id: 6,
        image: "images/car_F/1.jpg",
        location: "TX - DALLAS SOUTH",
        name: "2019 MERCEDES-BENZ A 220 4MATIC",
    },
    {
        id: 7,
        image: "images/car_G/1.jpg",
        location: "TX - DALLAS SOUTH",
        name: "2019 MERCEDES-BENZ A 220 4MATIC",
    },
    {
        id: 8,
        image: "images/car_B/3.jpg",
        location: "TX - DALLAS SOUTH",
        name: "2019 MERCEDES-BENZ A 220 4MATIC",
    }
]

export default InventoryData;